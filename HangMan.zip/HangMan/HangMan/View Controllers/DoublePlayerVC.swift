//
//  DoublePlayerVC.swift
//  HangMan
//
//  Created by Bharath Gandham on 9/12/19.
//  Copyright © 2019 Bharath Gandham. All rights reserved.
//

import UIKit

class DoublePlayerVC: UIViewController {

    @IBOutlet weak var tfGuessWord: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
    override func viewWillAppear(_ animated: Bool) {
        tfGuessWord.becomeFirstResponder()
        tfGuessWord.text=nil
    }
    
    @IBAction func btnActionMenu(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnActionPlay(_ sender: Any) {
        performSegue(withIdentifier: "doubleplayer2game", sender: self)
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "doubleplayer2game" {
            if let gameVC = segue.destination as? GameVC {
                if let enteredText = tfGuessWord.text {
                    gameVC.guessWord = enteredText
                }
            }
        }

    }
 

}
