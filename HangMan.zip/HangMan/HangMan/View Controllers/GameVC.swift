//
//  GameVC.swift
//  HangMan
//
//  Created by Bharath Gandham on 9/12/19.
//  Copyright © 2019 Bharath Gandham. All rights reserved.
//

import UIKit
import AVFoundation

class GameVC: UIViewController {
    var correctGuessSound = AVAudioPlayer()
    var wrongGuessSound = AVAudioPlayer()
    var guessWord = ""
    var curGuessCount = 0
    @IBOutlet weak var lblGuessWord: UILabel!
    
    @IBOutlet weak var imgViewHangman: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        createHiddenWord()
        setupCorrectGuessSound()
        setupWrongGuessSound()


    }
    func createHiddenWord() {
        var hiddenWord = ""
        for _ in guessWord {
            hiddenWord = hiddenWord + "-"
        }
        lblGuessWord.text = hiddenWord
    }
    func showAlert(title:String, message:String) {
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
    
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertAction.Style.default, handler: { _ in
                self.navigationController?.popViewController(animated: true)
            }))
            self.present(alert, animated: true, completion: nil)
        }
    func updateWord(revealLetter:String) {
    if guessWord.contains(revealLetter) {
        correctGuessSound.play()
        var hiddenWord = lblGuessWord.text
        var counter = 0
        for ch in guessWord {
            if ch == Array(revealLetter)[0] {
                var chars = Array(hiddenWord!)
                chars[counter] = Array(revealLetter)[0]
                hiddenWord = String(chars)
            }
            counter = counter + 1
        }
        lblGuessWord.text = hiddenWord
        
        if hiddenWord == guessWord {
            showAlert(title: "Win", message: "Congratulations, You won!")
        }
    }
        else {
        wrongGuessSound.play()
                curGuessCount = curGuessCount + 1
                
                if curGuessCount <= 10 {
                    imgViewHangman.image = UIImage(named: String(curGuessCount))
                }
                else {
                    showAlert(title: "Lost", message: "Sorry, You lost! The word is " + guessWord)
                }
            }
        }

    @IBAction func btnAction(_ sender: Any) {
        let btn = sender as! UIButton
        btn.isEnabled = false
        updateWord(revealLetter: btn.titleLabel!.text!.lowercased())
    }


    @IBAction func btnActionBack(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    func setupCorrectGuessSound() {
        if let correctGuessPath = Bundle.main.path(forResource: "lasersound", ofType: "wav") {
            let correctGuessURL = URL(fileURLWithPath: correctGuessPath)
            do {
                correctGuessSound = try AVAudioPlayer(contentsOf: correctGuessURL)
            } catch {
                print("failed ro load sound file")
            }
        }
    }
    func setupWrongGuessSound(){
        if let wrongGuessPath = Bundle.main.path(forResource: "buzzer", ofType: "wav") {
            let wrongGuessURL = URL(fileURLWithPath: wrongGuessPath)
            do {
                wrongGuessSound = try AVAudioPlayer(contentsOf: wrongGuessURL)
            } catch {
                print("failed ro load sound file")
            }
        }

    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
